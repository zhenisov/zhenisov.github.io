<form method="POST" action="mail.php" id="form_zayavka">
	<input type="text" name="name" placeholder="Имя" required>
	<input type="tel" name="phone" placeholder="Телефон" required>
	<a class="request-form__button" onclick="form_submit()">Отправить
		заявку</a>
</form>